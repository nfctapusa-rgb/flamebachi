# FlameBachi Clover Order-First Payment Fix

This release changes online card/Apple Pay checkout from:

payment -> generic Clover charge order -> try to repair order

to:

website order -> Clover order with exact total + line items -> pay that Clover order -> fulfillment/print.

The previous direct `/v1/charges` flow could leave a generic/empty `$0.00` order in Clover when the returned charge/order relationship was not usable for the later sync. Clover documents the order-first flow: create an order, then use `POST /v1/orders/{orderId}/pay` with the single-use payment source. The Apple Pay token is valid as a payment source for that endpoint.
