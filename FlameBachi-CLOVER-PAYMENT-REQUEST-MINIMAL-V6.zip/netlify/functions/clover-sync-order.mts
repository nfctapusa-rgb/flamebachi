import type { Context, Config } from '@netlify/functions';
import { getOrder, updateOrder } from './shared/orders.mjs';
import { createCloverOrder, syncExistingCloverOrder } from './shared/clover-order.mjs';

const json=(body:any,status=200)=>new Response(JSON.stringify(body),{status,headers:{'content-type':'application/json','cache-control':'no-store'}});

export default async (req:Request,_context:Context)=>{
  if(req.method!=='POST')return json({error:'Method not allowed'},405);
  let orderId='';
  try{
    const b=await req.json().catch(()=>({}));
    orderId=String(b.orderId||'');
    if(!orderId)return json({error:'Order ID is required.'},400);
    const order=await getOrder(orderId);
    if(!order)return json({error:'Order not found.'},404);
    if(order.cloverSyncState==='SYNCED'&&order.cloverOrderId)return json({ok:true,order});
    if(order.paymentMethod==='card'&&order.status!=='PAID')return json({error:'Card payment is not complete.'},409);

    await updateOrder(orderId,{cloverSyncState:'SYNCING',cloverSyncError:''});
    const fresh=await getOrder(orderId);
    let cloverOrderId=String(fresh?.cloverOrderId||'');
    if(cloverOrderId){
      await syncExistingCloverOrder(fresh,cloverOrderId,fresh.cloverPaymentId||'');
    }else{
      cloverOrderId=await createCloverOrder(fresh,fresh.cloverPaymentId||'');
    }
    const updated=await updateOrder(orderId,{cloverOrderId,cloverSyncState:'SYNCED',cloverSyncError:''});
    return json({ok:true,order:updated});
  }catch(e){
    console.error('[clover-sync-order]',e);
    try{
      if(orderId)await updateOrder(orderId,{cloverSyncState:'FAILED',cloverSyncError:String((e as any)?.message||e||'Clover sync failed')});
    }catch{}
    throw e;
  }
};

export const config:Config={path:'/api/clover/sync-order',background:true};
