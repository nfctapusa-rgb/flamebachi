import type { Context } from '@netlify/functions';
import { getOrder, updateOrder } from './shared/orders.mjs';
import { attachAndPopulateEcommerceOrder, createCloverCharge, getCloverEcommerceCharge, syncPaidCloverOrder } from './shared/clover-order.mjs';

const json=(body:any,status=200)=>new Response(JSON.stringify(body),{status,headers:{'content-type':'application/json','cache-control':'no-store'}});

export default async (req:Request,_context:Context)=>{
  if(req.method!=='POST')return json({error:'Method not allowed'},405);
  let localOrderId='';
  let cloverOrderId='';
  try{
    const b=await req.json();
    localOrderId=String(b.orderId||'');
    const source=String(b.source||'');
    const browserInfo=b?.browserInfo&&typeof b.browserInfo==='object'?b.browserInfo:null;
    const paymentKind=b?.wallet==='apple'||b?.wallet==='google'?'wallet':'card';
    const order=await getOrder(localOrderId);
    if(!order)return json({error:'Order not found.'},404);
    if(order.paymentMethod!=='card')return json({error:'This order is not a card order.'},400);
    if(order.status==='PAID')return json({ok:true,order});
    if(!source.startsWith('clv_'))return json({error:'Invalid Clover payment token.'},400);

    const clientIp=(req.headers.get('x-forwarded-for')||req.headers.get('x-nf-client-connection-ip')||req.headers.get('client-ip')||'').split(',')[0].trim();
    if(!clientIp)return json({error:'Clover could not determine the customer IP address.'},400);

    // Production payment path: use Clover's Create Charge endpoint. Clover documents
    // this as the standard hosted-iframe flow and it requires only Online Payments,
    // unlike Pay-for-Order which additionally requires multiple order/customer/read permissions.
    // Clover creates the associated order automatically; we locate it by the unique
    // external reference and then populate the restaurant order details via the Platform API.
    let charge:any;
    try{
      charge=await createCloverCharge(source,clientIp,browserInfo,order,paymentKind);
    }catch(e:any){
      const status=Number(e?.status||402);
      const data=e?.data&&typeof e.data==='object'?e.data:{};
      const failedChargeId=String(data?.charge||data?.charge_id||data?.id||'');
      console.error('[clover-charge] create-charge rejected',status,{
        code:data?.code||data?.error_code||data?.error?.code||null,
        decline_code:data?.decline_code||null,
        type:data?.type||null,
        message:data?.message||data?.error?.message||data?.error||null,
        charge:failedChargeId||null
      });

      // Clover documents that a 400 card error can include a charge identifier.
      // If Clover created a successful charge but the HTTP response was an error,
      // reconcile that charge before ever telling the customer to retry.
      if(failedChargeId){
        try{
          const existing=await getCloverEcommerceCharge(failedChargeId);
          if(existing?.paid===true || existing?.status==='succeeded'){
            charge=existing;
            console.warn('[clover-charge] Clover returned an error response but the charge is already successful; reconciling instead of retrying.',failedChargeId);
          }else{
            return json({
              error:data?.message||data?.error||'Clover declined the payment.',
              detail:data?.details||undefined,
              cloverCode:data?.code||data?.error_code||data?.error?.code||'card_error',
              declineCode:data?.decline_code||undefined,
              cloverStatus:status,
              chargeId:failedChargeId,
              paymentStatus:existing?.status||null,
              paid:existing?.paid===true
            },status===401?401:400);
          }
        }catch(reconcileError){
          console.error('[clover-charge] could not reconcile failed charge',reconcileError);
          return json({
            error:data?.message||data?.error||'Clover declined the payment. If your bank shows a pending charge, do not retry until that pending authorization clears.',
            detail:data?.details||undefined,
            cloverCode:data?.code||data?.error_code||data?.error?.code||'card_error',
            declineCode:data?.decline_code||undefined,
            cloverStatus:status,
            chargeId:failedChargeId
          },status===401?401:400);
        }
      }else{
        return json({
          error:data?.message||data?.error||'Clover payment failed.',
          detail:data?.details||undefined,
          cloverCode:data?.code||data?.error_code||data?.error?.code||undefined,
          declineCode:data?.decline_code||undefined,
          cloverStatus:status,
          cloverResponse:data
        },status===401?401:400);
      }
    }

    const validation=String(charge?.threeds?.validation_result||'');
    let located:any=null;
    try{
      located=await attachAndPopulateEcommerceOrder(order,charge);
      cloverOrderId=String(located.cloverOrderId||'');
      await updateOrder(localOrderId,{cloverOrderId,cloverPaymentId:String(charge?.id||''),cloverSyncState:'PAYMENT_PENDING',cloverSyncError:''});
    }catch(e:any){
      console.error('[clover-charge] charge succeeded but Clover order mapping/population failed',e);
      // Do not tell the customer the payment failed. The card has already been charged.
      await updateOrder(localOrderId,{cloverPaymentId:String(charge?.id||''),cloverSyncState:'SYNC_PENDING',cloverSyncError:String(e?.message||e||'Clover order mapping failed')});
      return json({ok:true,paymentPendingSync:true,order:await getOrder(localOrderId),paymentId:String(charge?.id||''),error:'Payment succeeded; Clover order details are still syncing.'},202);
    }

    if(validation && !['AUTHENTICATION_SUCCESSFUL','SUCCESS'].includes(validation)){
      if(validation==='THREEDS_METHOD_FLOW_REQUIRED'||validation==='CHALLENGE_FLOW_REQUIRED'){
        await updateOrder(localOrderId,{cloverSyncState:'PAYMENT_PENDING',cloverSyncError:validation,clover3dsChargeId:String(charge?.id||'')});
        return json({ok:false,threedsRequired:true,cloverCode:validation,threeds:charge?.threeds||null,chargeId:String(charge?.id||''),cloverOrderId});
      }
      await updateOrder(localOrderId,{cloverSyncState:'FAILED',cloverSyncError:validation});
      return json({error:'Clover declined the payment during 3-D Secure verification.',cloverCode:validation,threedsRequired:false,threeds:charge?.threeds||null},402);
    }

    const paymentId=String(charge?.id||'');
    const paid=await updateOrder(localOrderId,{status:'PAID',paymentState:'SUCCEEDED',paidAt:new Date().toISOString(),cloverPaymentId:paymentId,cloverOrderId,cloverSyncState:'SYNCED',cloverSyncError:''});
    try{
      const synced=await syncPaidCloverOrder(paid,cloverOrderId,paymentId);
      const final=await updateOrder(localOrderId,{cloverSyncState:'SYNCED',cloverPrintEventId:synced.printEventId||''});
      return json({ok:true,order:final,cloverOrderId,paymentId});
    }catch(e){
      console.error('[clover-charge] payment succeeded but print/update failed',e);
      const final=await updateOrder(localOrderId,{cloverSyncState:'SYNC_PENDING',cloverSyncError:String((e as any)?.message||e||'Clover print/update failed')});
      return json({ok:true,order:final,cloverOrderId,paymentId,printPending:true});
    }
  }catch(e:any){
    console.error('[clover-charge] unexpected failure',e);
    return json({error:e?.message||'Payment could not be completed.',cloverOrderId:cloverOrderId||undefined},500);
  }
};

export const config={path:'/api/clover/charge'};
