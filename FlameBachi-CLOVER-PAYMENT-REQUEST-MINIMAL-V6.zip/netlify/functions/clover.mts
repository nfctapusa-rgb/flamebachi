import { updateOrder, getOrder } from './shared/orders.mjs';
import { createCloverOrder } from './shared/clover-order.mjs';
const json=(body,status=200)=>new Response(JSON.stringify(body),{status,headers:{"content-type":"application/json","cache-control":"no-store"}});
const env=(name)=>{const v=Netlify.env.get(name);if(!v)throw new Error(`${name} is not configured`);return v;};
const production=()=>String(Netlify.env.get('CLOVER_ENV')||'production').toLowerCase()!=='sandbox';
const hcoBase=()=>production()?'https://scl.clover.com':'https://scl-sandbox.dev.clover.com';
const merchant=()=>env('CLOVER_MERCHANT_ID');
export default async req=>{
 if(req.method!=="POST")return json({error:"Method not allowed"},405);
 try{
  const b=await req.json();const order=await getOrder(String(b.orderId||""));if(!order)return json({error:"Order not found."},404);
  if(order.paymentMethod!=="card")return json({error:"Clover checkout is only for card orders."},400);
  const body={customer:{firstName:String(order.customer?.name||"Customer").split(' ')[0],lastName:String(order.customer?.name||"").split(' ').slice(1).join(' ')||"Customer",phoneNumber:order.customer?.phone,email:order.customer?.email||undefined},redirectUrls:{successUrl:`${new URL(req.url).origin}/online-menu/?clover=success&order=${encodeURIComponent(order.id)}`,failureUrl:`${new URL(req.url).origin}/online-menu/?clover=failure&order=${encodeURIComponent(order.id)}`,cancelUrl:`${new URL(req.url).origin}/online-menu/?clover=cancelled&order=${encodeURIComponent(order.id)}`},shoppingCart:{lineItems:(order.items||[]).map(i=>({name:i.name,note:[i.baseChoice&&i.baseChoice!=="Standard"?`Rice: ${i.baseChoice}`:"",i.drink&&i.drink!=="No drink"?`Drink: ${i.drink}`:"",i.sauce&&i.sauce!=="None"?`Sauce: ${i.sauce}`:"",(i.substitutions||[]).map(x=>x.name).join(', '),(i.addons||[]).map(x=>x.name).join(', '),i.specialInstructions?`Note: ${i.specialInstructions}`:""].filter(Boolean).join(' • '),price:Math.round((Number(i.lineTotalC)||0)/(Number(i.qty)||1)),unitQty:Number(i.qty)||1,taxRates:[{name:`CA Sales Tax ${Number(order.taxRate||0).toFixed(3)}%`,rate:Math.round(Number(order.taxRate||0)*100000)}]}))}};
  const pageConfigUuid=Netlify.env.get('CLOVER_HCO_PAGE_CONFIG_UUID');if(pageConfigUuid)body.pageConfigUuid=pageConfigUuid;
  const r=await fetch(`${hcoBase()}/invoicingcheckoutservice/v1/checkouts`,{method:'POST',headers:{accept:'application/json','content-type':'application/json','X-Clover-Merchant-Id':merchant(),Authorization:`Bearer ${env('CLOVER_HCO_PRIVATE_KEY')}`},body:JSON.stringify(body)});
  const data=await r.json().catch(()=>({}));if(!r.ok)return json({error:'Unable to start Clover checkout.',detail:data?.message||data?.error||data},502);
  await updateOrder(order.id,{paymentState:'CHECKOUT_CREATED',cloverCheckoutSessionId:data.checkoutSessionId,cloverCheckoutUrl:data.href});
  return json({href:data.href,checkoutSessionId:data.checkoutSessionId,orderId:order.id});
 }catch(e){return json({error:e?.message||'Unable to start Clover checkout.'},500)}
};
export const config={path:'/api/clover/checkout'};
export {createCloverOrder};
