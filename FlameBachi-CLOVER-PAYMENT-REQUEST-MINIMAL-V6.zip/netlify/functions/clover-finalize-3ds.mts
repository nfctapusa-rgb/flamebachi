import type { Context } from '@netlify/functions';
import { getOrder, updateOrder } from './shared/orders.mjs';
import { syncPaidCloverOrder } from './shared/clover-order.mjs';

const json=(body:any,status=200)=>new Response(JSON.stringify(body),{status,headers:{'content-type':'application/json','cache-control':'no-store'}});
const env=(name:string)=>{const v=Netlify.env.get(name);if(!v)throw new Error(`${name} is not configured`);return v;};
const production=()=>String(Netlify.env.get('CLOVER_ENV')||'production').toLowerCase()!=='sandbox';
const ecomBase=()=>production()?'https://scl.clover.com':'https://scl-sandbox.dev.clover.com';

export default async (req:Request,_context:Context)=>{
  if(req.method!=='POST')return json({error:'Method not allowed'},405);
  let orderId='';
  try{
    const b=await req.json();
    orderId=String(b.orderId||'');
    const chargeId=String(b.chargeId||'');
    const flowStatus=b.flowStatus;
    const order=await getOrder(orderId);
    if(!order)return json({error:'Order not found.'},404);
    if(!order.cloverOrderId)return json({error:'Clover order ID is missing.'},409);
    if(!chargeId)return json({error:'3-D Secure charge ID is missing.'},400);
    if(!flowStatus)return json({error:'3-D Secure flow status is missing.'},400);
    const clientIp=(req.headers.get('x-forwarded-for')||req.headers.get('x-nf-client-connection-ip')||req.headers.get('client-ip')||'').split(',')[0].trim();
    const r=await fetch(`${ecomBase()}/v1/charges/finalize_payment`,{
      method:'POST',headers:{accept:'application/json','content-type':'application/json',authorization:`Bearer ${env('CLOVER_IFRAME_PRIVATE_KEY')}`,...(clientIp?{'x-forwarded-for':clientIp}:{})},
      body:JSON.stringify({charge_id:chargeId,threeds:{source:'CLOVER',flow_status:flowStatus}})
    });
    const data=await r.json().catch(()=>({}));
    if(!r.ok){console.error('[clover-finalize-3ds]',r.status,data);return json({error:data?.message||data?.error||'3-D Secure finalization failed.',cloverCode:data?.code||data?.error_code,detail:data?.details},402);}
    const validation=String(data?.threeds?.validation_result||data?.validation_result||'');
    if(validation && !['AUTHENTICATION_SUCCESSFUL','SUCCESS'].includes(validation)){
      await updateOrder(orderId,{cloverSyncState:'FAILED',cloverSyncError:validation});
      return json({error:'3-D Secure authentication was not successful.',cloverCode:validation,threeds:data?.threeds||null},402);
    }
    const paymentId=String(data?.charge?.id||data?.charge||data?.id||data?.payment?.id||order.cloverPaymentId||'');
    const paid=await updateOrder(orderId,{status:'PAID',paymentState:'SUCCEEDED',paidAt:new Date().toISOString(),cloverPaymentId:paymentId,cloverSyncState:'SYNCED',cloverSyncError:''});
    try{
      const synced=await syncPaidCloverOrder(paid,String(order.cloverOrderId),paymentId);
      const final=await updateOrder(orderId,{cloverSyncState:'SYNCED',cloverPrintEventId:synced.printEventId||''});
      return json({ok:true,order:final,cloverOrderId:order.cloverOrderId,paymentId});
    }catch(e){
      console.error('[clover-finalize-3ds] payment succeeded but print failed',e);
      const final=await updateOrder(orderId,{cloverSyncState:'SYNC_PENDING',cloverSyncError:String((e as any)?.message||e||'Clover print failed')});
      return json({ok:true,order:final,cloverOrderId:order.cloverOrderId,paymentId,printPending:true});
    }
  }catch(e){console.error('[clover-finalize-3ds]',e);return json({error:(e as any)?.message||'3-D Secure finalization failed.',orderId},500);}
};
export const config={path:'/api/clover/finalize-3ds'};
