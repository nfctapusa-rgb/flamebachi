const env=(name)=>{const v=Netlify.env.get(name);if(!v)throw new Error(`${name} is not configured`);return v;};
const production=()=>String(Netlify.env.get('CLOVER_ENV')||'production').toLowerCase()!=='sandbox';
const apiBase=()=>production()?'https://api.clover.com':'https://apisandbox.dev.clover.com';
const ecomBase=()=>production()?'https://scl.clover.com':'https://scl-sandbox.dev.clover.com';
const merchant=()=>env('CLOVER_MERCHANT_ID');

function normalizePhone(phone=''){
  return String(phone||'').replace(/[^0-9+]/g,'').trim();
}
function splitCustomerName(name=''){
  const parts=String(name||'').trim().split(/\s+/).filter(Boolean);
  return {firstName:parts.shift()||'Online',lastName:parts.join(' ')||'Customer'};
}

async function findOrCreateCloverCustomer(order){
  const phone=normalizePhone(order.customer?.phone||order.phone||'');
  const email=String(order.customer?.email||order.email||'').trim().toLowerCase();
  const name=String(order.customer?.name||order.name||'Online Customer').trim();
  if(!phone && !email) return null;
  try{
    const filters=[];
    if(phone)filters.push(`filter=phoneNumber=${encodeURIComponent(phone)}`);
    if(email)filters.push(`filter=emailAddress=${encodeURIComponent(email)}`);
    for(const filter of filters){
      try{
        const found=await cloverFetch(`/v3/merchants/${encodeURIComponent(merchant())}/customers?${filter}&expand=phoneNumbers,emailAddresses`,{method:'GET'});
        const existing=Array.isArray(found?.elements)?found.elements[0]:null;
        if(existing?.id) return String(existing.id);
      }catch(e){ console.warn('[clover] customer lookup failed',e); }
    }
  }catch(e){ console.warn('[clover] customer lookup failed',e); }
  const {firstName,lastName}=splitCustomerName(name);
  const body={firstName,lastName,customerSince:Date.now(),metadata:{note:`FlameBachi online customer. Phone: ${phone||'N/A'}${email?` Email: ${email}`:''}`}};
  if(phone)body.phoneNumbers=[{phoneNumber:phone}];
  if(email)body.emailAddresses=[{emailAddress:email,primaryEmail:true}];
  try{
    const created=await cloverFetch(`/v3/merchants/${encodeURIComponent(merchant())}/customers`,{method:'POST',body:JSON.stringify(body)});
    return created?.id?String(created.id):null;
  }catch(e){
    console.warn('[clover] customer creation failed; order note will still contain customer info',e);
    return null;
  }
}

async function cloverFetch(path,init={}){
  const r=await fetch(`${apiBase()}${path}`,{...init,headers:{accept:'application/json','content-type':'application/json',Authorization:`Bearer ${env('CLOVER_REST_TOKEN')}`,...(init.headers||{})}});
  const text=await r.text();let data={};try{data=text?JSON.parse(text):{};}catch{data={raw:text};}
  if(!r.ok)throw new Error(`Clover ${r.status}: ${data?.message||data?.error||text||'request failed'}`);
  return data;
}
async function ecomFetch(path,init={}){
  const r=await fetch(`${ecomBase()}${path}`,{...init,headers:{accept:'application/json','content-type':'application/json',Authorization:`Bearer ${env('CLOVER_IFRAME_PRIVATE_KEY')}`,...(init.headers||{})}});
  const text=await r.text();let data={};try{data=text?JSON.parse(text):{};}catch{data={raw:text};}
  if(!r.ok){const err=new Error(`Clover Ecommerce ${r.status}: ${data?.message||data?.error||text||'request failed'}`);err.status=r.status;err.data=data;throw err;}
  return data;
}

function lineItems(order){
  return (order.items||[]).map(item=>{
    const details=[
      item.baseChoice&&item.baseChoice!=='Standard'?`Rice: ${item.baseChoice}`:'',
      item.drink&&item.drink!=='No drink'?`Drink: ${item.drink}`:'',
      item.sauce&&item.sauce!=='None'?`Sauce: ${item.sauce}`:'',
      (item.substitutions||[]).map(x=>x.name).join(', '),
      (item.addons||[]).map(x=>x.name).join(', '),
      item.specialInstructions?`Note: ${item.specialInstructions}`:''
    ].filter(Boolean).join(' • ');
    return {name:item.name,price:Math.round((Number(item.lineTotalC)||0)/(Number(item.qty)||1)),unitQty:Number(item.qty)||1,note:details||undefined};
  });
}

async function getPickupOrderType(){
  try{
    const data=await cloverFetch(`/v3/merchants/${encodeURIComponent(merchant())}/order_types`,{method:'GET'});
    const elements=Array.isArray(data?.elements)?data.elements:[];
    return elements.find(x=>/pick|take.?out|to.?go/i.test(String(x?.name||'')))||null;
  }catch(e){
    console.warn('[clover] could not load order types',e);
    return null;
  }
}

async function getSalesTaxRate(){
  try{
    const data=await cloverFetch(`/v3/merchants/${encodeURIComponent(merchant())}/tax_rates`,{method:'GET'});
    const elements=Array.isArray(data?.elements)?data.elements:[];
    return elements.find(x=>Math.abs(Number(x?.rate||0)-1025000)<=1)||elements.find(x=>/sales|ca|california/i.test(String(x?.name||''))&&Number(x?.rate||0)>0)||null;
  }catch(e){
    console.warn('[clover] could not load tax rates',e);
    return null;
  }
}

function customerNote(order){
  return [
    `Customer: ${order.customer?.name||order.name||'N/A'}`,
    `Phone: ${order.customer?.phone||order.phone||'N/A'}`,
    order.customer?.email?`Email: ${order.customer.email}`:'',
    `Pickup: ${order.location||'Downtown LA'}`
  ].filter(Boolean).join(' • ');
}

function orderNote(order,paymentId=''){
  return `Website pickup • ${order.location||'Downtown LA'} • ${order.paymentMethod==='cash'?'CASH AT PICKUP':'PAID ONLINE'}${paymentId?` • Clover payment ${paymentId}`:''} • Website order ${order.orderNumber}\n${customerNote(order)}${Number(order.taxC||0)?`\nTax: $${(Number(order.taxC)/100).toFixed(2)}`:''}${order.testMode?'\n*** 10¢ CLOVER PRINT TEST — REAL PAYMENT ***':''}`;
}

async function printCloverOrder(cloverOrderId){
  if(!cloverOrderId)throw new Error('Clover order ID is missing for printing.');
  return await cloverFetch(`/v3/merchants/${encodeURIComponent(merchant())}/print_event`,{method:'POST',body:JSON.stringify({orderRef:{id:cloverOrderId}})});
}

export async function getCloverOrder(cloverOrderId){
  if(!cloverOrderId)return null;
  return await cloverFetch(`/v3/merchants/${encodeURIComponent(merchant())}/orders/${encodeURIComponent(cloverOrderId)}`,{method:'GET'});
}

export async function deleteCloverOrder(cloverOrderId){
  if(!cloverOrderId)return;
  try{await cloverFetch(`/v3/merchants/${encodeURIComponent(merchant())}/orders/${encodeURIComponent(cloverOrderId)}`,{method:'DELETE'});}catch(e){console.warn('[clover] cleanup failed',e);}
}

// Build the actual Clover restaurant order BEFORE asking Ecommerce to charge it.
// This prevents failed card/Apple Pay attempts from becoming blank orders and ensures
// a successful payment is attached to the same order that already contains the items.
async function populateCloverOrder(order,cloverOrderId,customerId=null){
  const type=await getPickupOrderType();
  const tax=order.testMode?null:await getSalesTaxRate();
  const items=lineItems(order);
  if(items.length){
    const payload={items:items.map(item=>{
      const body={name:item.name,price:Number(item.price),unitQty:Number(item.unitQty)||1};
      if(item.note)body.note=item.note;
      if(tax)body.taxRates=[{id:String(tax.id),name:String(tax.name||'Sales Tax'),rate:Number(tax.rate||1025000),isDefault:true}];
      return body;
    })};
    await cloverFetch(`/v3/merchants/${encodeURIComponent(merchant())}/orders/${encodeURIComponent(cloverOrderId)}/bulk_line_items`,{method:'POST',body:JSON.stringify(payload)});
  }
  const update={
    state:'Open',
    total:Number(order.totalC),
    currency:'USD',
    title:order.testMode?'FlameBachi Clover 10¢ Test':`FlameBachi ${order.orderNumber}`,
    note:orderNote(order),
    paymentState:order.paymentMethod==='cash'?'OPEN':'OPEN',
    taxRemoved:Boolean(order.testMode),
    groupLineItems:true,
    externalReferenceId:cloverExternalReference(order.orderNumber),
    clientCreatedTime:new Date(order.createdAt||Date.now()).getTime()
  };
  if(type?.id)update.orderType={id:String(type.id)};
  if(customerId)update.customers=[{id:String(customerId)}];
  if(Number(order.discountC||0)>0){
    try{
      await cloverFetch(`/v3/merchants/${encodeURIComponent(merchant())}/orders/${encodeURIComponent(cloverOrderId)}/discounts`,{method:'POST',body:JSON.stringify({name:'Website offer',amount:-Number(order.discountC)})});
    }catch(e){console.warn('[clover] website discount could not be attached',e);}
  }
  await cloverFetch(`/v3/merchants/${encodeURIComponent(merchant())}/orders/${encodeURIComponent(cloverOrderId)}`,{method:'POST',body:JSON.stringify(update)});
}

export async function createCardCloverOrder(order){
  if(order.cloverOrderId)return String(order.cloverOrderId);
  const type=await getPickupOrderType();
  const customerId=await findOrCreateCloverCustomer(order);
  const body={
    title:order.testMode?'FlameBachi Clover 10¢ Test':`FlameBachi ${order.orderNumber}`,
    state:'Open',currency:'USD',total:Number(order.totalC),
    note:orderNote(order),taxRemoved:Boolean(order.testMode),manualTransaction:false,groupLineItems:true,
    externalReferenceId:cloverExternalReference(order.orderNumber),clientCreatedTime:new Date(order.createdAt||Date.now()).getTime()
  };
  if(type?.id)body.orderType={id:String(type.id)};
  if(customerId)body.customers=[{id:String(customerId)}];
  const created=await cloverFetch(`/v3/merchants/${encodeURIComponent(merchant())}/orders`,{method:'POST',body:JSON.stringify(body)});
  const cloverOrderId=String(created?.id||'');
  if(!cloverOrderId)throw new Error('Clover created the order but did not return an order ID.');
  try{await populateCloverOrder(order,cloverOrderId,customerId);return cloverOrderId;}
  catch(error){error.cloverOrderId=cloverOrderId;throw error;}
}

export async function getCloverEcommerceCharge(chargeId){
  if(!chargeId)return null;
  return await ecomFetch(`/v1/charges/${encodeURIComponent(chargeId)}`,{method:'GET'});
}

function cloverExternalReference(orderNumber=''){
  // Clover US allows only alphanumeric characters and in-between spaces, max 12 chars.
  return String(orderNumber||'').replace(/[^A-Za-z0-9 ]/g,'').slice(0,12);
}

function hasComplete3DSBrowserInfo(info){
  if(!info || typeof info!=='object') return false;
  const required=['browser_accept_header','browser_ip','browser_javascript_enabled','browser_java_enabled','browser_language','browser_screen_height','browser_screen_width','browser_tz','browser_user_agent','browser_http_origin'];
  return required.every(k=>info[k]!==undefined && info[k]!==null && String(info[k])!=='');
}

export async function createCloverCharge(source,clientIp,browserInfo=null,order=null,paymentKind='card'){
  const amount=Math.trunc(Number(order?.totalC||0));
  if(!Number.isInteger(amount) || amount<1) throw new Error('Invalid Clover charge amount.');
  if(!/^clv_[A-Za-z0-9]+$/.test(String(source||''))) throw new Error('Invalid Clover payment token.');
  if(!clientIp) throw new Error('Clover customer IP address is missing.');

  // Keep the authorization request deliberately minimal. Clover documents amount,
  // currency and source as the required Create Charge body fields. The external
  // reference is retained only so we can reliably map Clover's auto-created order
  // back to the FlameBachi order after a successful charge.
  const body={
    source:String(source),
    amount,
    currency:'usd',
    external_reference_id:cloverExternalReference(order?.orderNumber||'')
  };

  // 3DS browser data is for the normal card flow only. Never attach it to Apple Pay
  // or Google Pay wallet tokens. If the card flow has a complete Clover 3DS payload,
  // send exactly the documented browser fields.
  const threeDSEnabled=String(Netlify.env.get('CLOVER_3DS_ENABLED')||'false').toLowerCase()==='true';
  if(paymentKind==='card' && threeDSEnabled && hasComplete3DSBrowserInfo(browserInfo)){
    body.threeds={source:'CLOVER',browser_info:{...browserInfo,browser_ip:clientIp}};
  }

  const idempotencyKey=String(order?.cloverIdempotencyKey||'');
  const headers={'x-forwarded-for':clientIp,'user-agent':'FlameBachi-Clover/8.0'};
  if(idempotencyKey)headers['idempotency-key']=idempotencyKey;
  return await ecomFetch('/v1/charges',{method:'POST',headers,body:JSON.stringify(body)});
}

async function findAutocreatedCloverOrder(order){
  const ref=cloverExternalReference(order?.orderNumber||'');
  if(!ref)return null;
  try{
    const data=await cloverFetch(`/v3/merchants/${encodeURIComponent(merchant())}/orders?filter=externalReferenceId=${encodeURIComponent(ref)}&expand=lineItems,customers,payments,orderType`,{method:'GET'});
    const elements=Array.isArray(data?.elements)?data.elements:[];
    const candidates=elements.filter(x=>String(x?.externalReferenceId||'')===ref);
    candidates.sort((a,b)=>Number(b?.createdTime||0)-Number(a?.createdTime||0));
    return candidates[0]||null;
  }catch(e){
    console.warn('[clover] could not locate Ecommerce-created order',e);
    return null;
  }
}

export async function attachAndPopulateEcommerceOrder(order,charge){
  const found=await findAutocreatedCloverOrder(order);
  const cloverOrderId=String(found?.id||'');
  if(!cloverOrderId)throw new Error('Clover charged the payment but the corresponding Clover order could not be located yet.');
  const customerId=await findOrCreateCloverCustomer(order);
  await populateCloverOrder({...order,cloverCustomerId:customerId},cloverOrderId,customerId);
  return {cloverOrderId,customerId,chargeId:String(charge?.id||'')};
}

export async function payCloverOrder(cloverOrderId,source,clientIp,browserInfo=null,order=null){
  if(!cloverOrderId)throw new Error('Clover order ID is missing.');
  const body={
    source,
    ecomind:'ecom',
    amount:Number(order?.totalC||0),
    currency:'usd',
    metadata:{delete_order_on_failure:true},
    external_reference_id:cloverExternalReference(order?.orderNumber||''),
    external_customer_reference:String(order?.customer?.phone||'').slice(0,50)
  };
  if(order?.customer?.email)body.email=String(order.customer.email);
  if(order?.cloverCustomerId)body.customer=String(order.cloverCustomerId);
  if(browserInfo){body.threeds={source:'CLOVER',browser_info:{...browserInfo,browser_ip:clientIp}};}
  return await ecomFetch(`/v1/orders/${encodeURIComponent(cloverOrderId)}/pay`,{method:'POST',headers:{'x-forwarded-for':clientIp,'user-agent':'FlameBachi-Clover/5.0'},body:JSON.stringify(body)});
}

export async function syncExistingCloverOrder(order,cloverOrderId,paymentId=''){
  if(!cloverOrderId)throw new Error('Clover order ID is missing.');
  // Card orders that have already been paid only need the final Clover update/print.
  // Cash orders can reach this retry path before payment, so keep them Open and print them.
  const note=orderNote(order,paymentId);
  await cloverFetch(`/v3/merchants/${encodeURIComponent(merchant())}/orders/${encodeURIComponent(cloverOrderId)}`,{method:'POST',body:JSON.stringify({state:'Open',total:Number(order.totalC),currency:'USD',title:order.testMode?'FlameBachi Clover 10¢ Test':`FlameBachi ${order.orderNumber}`,note,taxRemoved:Boolean(order.testMode),paymentState:order.paymentMethod==='cash'?'OPEN':(order.status==='PAID'?'PAID':'OPEN'),externalReferenceId:cloverExternalReference(order.orderNumber),groupLineItems:true,...(order.cloverCustomerId?{customers:[{id:String(order.cloverCustomerId)}]}:{})})});
  let printEventId=String(order.cloverPrintEventId||'');
  if(!printEventId){
    const printEvent=await printCloverOrder(cloverOrderId);
    printEventId=String(printEvent?.id||'');
  }
  return {cloverOrderId,printEventId};
}

export async function syncPaidCloverOrder(order,cloverOrderId,paymentId=''){
  if(!cloverOrderId)throw new Error('Clover order ID is missing.');
  const note=orderNote(order,paymentId);
  await cloverFetch(`/v3/merchants/${encodeURIComponent(merchant())}/orders/${encodeURIComponent(cloverOrderId)}`,{method:'POST',body:JSON.stringify({state:'Open',paymentState:'PAID',total:Number(order.totalC),currency:'USD',title:order.testMode?'FlameBachi Clover 10¢ Test':`FlameBachi ${order.orderNumber}`,note,externalReferenceId:cloverExternalReference(order.orderNumber),groupLineItems:true,...(order.cloverCustomerId?{customers:[{id:String(order.cloverCustomerId)}]}:{})})});
  let printEventId=String(order.cloverPrintEventId||'');
  if(!printEventId){
    const printEvent=await printCloverOrder(cloverOrderId);
    printEventId=String(printEvent?.id||'');
  }
  return {cloverOrderId,printEventId};
}

// Cash orders stay on the Platform API because there is no online payment token.
export async function createCloverOrder(order,paymentId=''){
  if(order.cloverOrderId)return order.cloverOrderId;
  const type=await getPickupOrderType();
  const body={title:order.testMode?'FlameBachi Clover 10¢ Test':`FlameBachi ${order.orderNumber}`,state:'Open',currency:'USD',total:Number(order.totalC),note:orderNote(order,paymentId),taxRemoved:Boolean(order.testMode),manualTransaction:false,groupLineItems:true};
  if(type?.id)body.orderType={id:String(type.id)};
  const customerId=await findOrCreateCloverCustomer(order);
  if(customerId)body.customers=[{id:String(customerId)}];
  body.externalReferenceId=cloverExternalReference(order.orderNumber);
  const created=await cloverFetch(`/v3/merchants/${encodeURIComponent(merchant())}/orders`,{method:'POST',body:JSON.stringify(body)});
  try{
    await populateCloverOrder({...order,paymentMethod:'cash',cloverCustomerId:customerId},String(created.id),customerId);
    return String(created.id);
  }catch(error){error.cloverOrderId=String(created.id);throw error;}
}
