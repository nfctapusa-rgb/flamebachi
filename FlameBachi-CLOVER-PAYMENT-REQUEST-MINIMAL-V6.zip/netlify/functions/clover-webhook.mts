import { getOrder, updateOrder } from './shared/orders.mjs';
import { createCloverOrder } from './shared/clover-order.mjs';
const json=(body,status=200)=>new Response(JSON.stringify(body),{status,headers:{'content-type':'application/json'}});
const env=(name)=>{const v=Netlify.env.get(name);if(!v)throw new Error(`${name} is not configured`);return v;};
async function verifySignature(req,raw){
  const secret=Netlify.env.get('CLOVER_WEBHOOK_SECRET');
  if(!secret)return true;
  const sig=req.headers.get('Clover-Signature')||'';const m=sig.match(/^t=(\d+),v1=([a-f0-9]+)$/i);if(!m)return false;
  const [,timestamp,expected]=m;
  const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  const digest=await crypto.subtle.sign('HMAC',key,new TextEncoder().encode(`${timestamp}.${raw}`));
  const actual=Array.from(new Uint8Array(digest)).map(x=>x.toString(16).padStart(2,'0')).join('');
  return actual===expected;
}
export default async req=>{
  if(req.method!=='POST')return json({error:'Method not allowed'},405);
  const raw=await req.text();
  if(!(await verifySignature(req,raw)))return json({error:'Invalid signature'},401);
  try{
    const event=JSON.parse(raw);const checkoutSessionId=String(event?.data||event?.checkoutSessionId||'');const status=String(event?.status||'').toUpperCase();const paymentId=String(event?.id||'');
    if(!checkoutSessionId)return json({received:true});
    const {listOrders}=await import('./shared/orders.mjs');const orders=await listOrders();
    const order=orders.find(o=>o.cloverCheckoutSessionId===checkoutSessionId);
    if(!order)return json({received:true});
    if(status==='APPROVED'){
      const cloverOrderId=await createCloverOrder(order,paymentId);
      await updateOrder(order.id,{status:'PAID',paymentState:'SUCCEEDED',paidAt:new Date().toISOString(),cloverPaymentId:paymentId,cloverOrderId});
    }else if(status==='DECLINED'){
      await updateOrder(order.id,{paymentState:'DECLINED',cloverPaymentId:paymentId});
    }
    return json({received:true});
  }catch(e){console.error('[clover-webhook]',e);return json({error:e?.message||'Webhook processing failed'},500)}
};
export const config={path:'/api/clover/webhook'};
