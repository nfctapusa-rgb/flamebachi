const json=(body,status=200)=>new Response(JSON.stringify(body),{status,headers:{'content-type':'application/json','cache-control':'no-store'}});
export default async req=>{
  if(req.method!=='GET')return json({error:'Method not allowed'},405);
  const apiAccessKey=Netlify.env.get('CLOVER_IFRAME_PUBLIC_KEY')||Netlify.env.get('CLOVER_PUBLIC_TOKEN')||Netlify.env.get('CLOVER_API_ACCESS_KEY')||'';
  const merchantId=Netlify.env.get('CLOVER_MERCHANT_ID')||'';
  const appleSessionIdentifier=Netlify.env.get('CLOVER_APPLE_SESSION_IDENTIFIER')||Netlify.env.get('CLOVER_MERCHANT_UUID')||Netlify.env.get('CLOVER_APP_UUID')||'';
  if(!apiAccessKey||!merchantId)return json({error:'Clover hosted iframe is not configured yet.',missing:{publicToken:!apiAccessKey,merchantId:!merchantId}},503);
  const threeDS=String(Netlify.env.get('CLOVER_3DS_ENABLED')||'false').toLowerCase()==='true';
  return json({apiAccessKey,merchantId,appleSessionIdentifier,appleConfigured:Boolean(appleSessionIdentifier),threeDS});
};
export const config={path:'/api/clover/config'};
