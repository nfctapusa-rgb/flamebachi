# FlameBachi — permanent pickup checkout / Clover release

This package keeps the FlameBachi customer-facing frontend and connects checkout to Clover.

### This release
- Fixed checkout tax-rate math so 10.250% is calculated as 10.250%, not 0.1025%.
- Checkout/cart totals use integer cents.
- Checkout draft version is v4 and clears the previous v3 draft to prevent stale duplicate test items.
- Added a controlled Clover live-payment test item available only with `?test=1`.
- The Clover test item is exactly $0.10 with no tax, so the charge is exactly 10 cents.
- Customer name, phone, email, pickup location and website order number are included in the Clover order note.
- Clover order printing uses the merchant default firing printer via `print_event`.
- Clover line-item synchronization and printing are retry-safe to prevent duplicate line items/print jobs.
- Apple Pay remains fresh per checkout and the payment response is not blocked by the slower Clover sync/print work.

## Test
1. Deploy this package.
2. Open the deployed site with `?test=1`.
3. Choose **Clover Print Test — $0.10**.
4. Enter test customer name and phone.
5. Confirm checkout says **Subtotal $0.10, Tax $0.00, Total $0.10**.
6. Pay with Apple Pay on Safari.
7. Verify the payment completes, the Clover order appears, customer information is visible in the Clover order note, and the Station Duo/default order printer prints it.

The $0.10 test is a real production payment. Do not repeat it unnecessarily.


## Latest checkout fix
- Standalone sauces, sides, add-ons, and the Clover test item are now non-customizable in the item sheet, so a $1 sauce cannot accidentally become $2 by adding itself as its own sauce.
- The Test category is visible only at `?test=1` and contains the $0.10 Clover Print Test.
- Server-side order validation also ignores option extras for those simple categories.
