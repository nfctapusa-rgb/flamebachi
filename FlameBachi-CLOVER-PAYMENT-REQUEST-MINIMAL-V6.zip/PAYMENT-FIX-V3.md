# FlameBachi Clover Production Payment Fix V3

This build keeps the existing FlameBachi frontend and production checkout architecture.

Payment changes:
- Uses Clover Ecommerce Create Charge for card and Apple Pay tokens.
- Sends the final server-calculated total as `amount` and does not send a separate `tax_amount` on the payment request.
- Keeps Clover idempotency keys so retries do not create duplicate charges.
- Preserves supported external reference/customer reference/receipt metadata.
- Only sends Clover 3DS browser data when a browser IP is present.
- If Clover returns a 400 with a charge identifier, the backend retrieves that charge before telling the customer to retry. If Clover says the charge succeeded, the website reconciles it instead of generating a second charge.
- If Clover truly declined the transaction, the response includes the Clover code/decline code so the failure is actionable.

Important: A bank showing a pending amount after a Clover decline can be a temporary authorization hold. The site must never tell a customer to retry blindly when Clover returned a charge ID; this build reconciles that case first.
