# FlameBachi Clover Payment Request Fix V6

This build preserves the existing FlameBachi menu/cart/checkout frontend and changes only the Clover payment request path.

## Payment request

The Ecommerce Create Charge request is intentionally minimal:
- amount (server-calculated final cents)
- currency = usd
- source = fresh clv_ token
- external_reference_id = sanitized FLM reference (used only to map Clover's auto-created order)
- x-forwarded-for header
- UUID idempotency key

Optional customer metadata, receipt_email, external_customer_reference, and ecomind are not sent to the gateway authorization request.

## 3DS

3DS is opt-in through `CLOVER_3DS_ENABLED`.
- `false` (default): no 3DS object is attached to a card charge.
- `true`: the production Clover 3DS SDK/browser data is used for card payments only.
- Apple Pay and Google Pay never receive the card 3DS browser payload.

If 3DS is enabled in Clover Merchant Dashboard, set `CLOVER_3DS_ENABLED=true` and redeploy.

## Order sync

After a successful charge, Clover's auto-created order is located using the same sanitized external reference. The build then adds all FlameBachi line items through Clover's bulk_line_items endpoint, associates the customer, sets pickup order type, updates the order, and triggers the print event.
