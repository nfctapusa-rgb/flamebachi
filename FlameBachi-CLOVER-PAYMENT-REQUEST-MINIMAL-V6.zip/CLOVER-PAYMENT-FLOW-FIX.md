# FlameBachi Clover production payment flow

This build uses Clover's Ecommerce **Create Charge** endpoint as the primary production card/Apple Pay payment path.

Why: Clover documents `POST /v1/charges` as the standard Hosted iFrame server-to-server payment flow and says it requires the **Online payments** permission. Clover's `POST /v1/orders/{orderId}/pay` requires additional Read Customers, Read Inventory, Read Merchant, Read Orders, Read Payments, and Online Payments permissions. Using Create Charge avoids making checkout depend on those extra Pay-for-Order permissions while still creating a Clover order for the transaction.

Flow:
1. Website creates the server-authoritative pending order and a UUIDv4 idempotency key.
2. Clover Hosted iFrame / Apple Pay supplies a single-use `clv_` source token.
3. Netlify calls production `https://scl.clover.com/v1/charges` with amount, source, currency, x-forwarded-for, idempotency-key, and 3DS browser information when available.
4. Clover creates the payment/order.
5. The site locates the new Clover order using the unique website order reference.
6. Platform API attaches customer/order details, line items, pickup order type, tax and website notes.
7. Successful payment is marked PAID locally and Clover print_event is fired so the Station Duo can print it.
8. 3DS method/challenge responses remain pending until `/api/clover/finalize-3ds` completes the flow.

No private token is stored in source. Environment variables remain required.
