# Apple Pay event handling fix

This build changes the Apple Pay event listeners to the `window` level required by Clover's current Hosted IFrame Apple Pay documentation. The Apple Pay `paymentMethod` event carries the single-use Clover token; the site then sends that token to `/api/clover/charge` and updates the Apple Pay session status within the 30-second session window.

No Clover credentials are embedded in this package. Keep all private values in Netlify environment variables.
