# FlameBachi — Apple Pay / Clover order-first flow

## What changed

The previous card/Apple Pay implementation used Clover `POST /v1/charges`. Clover's Ecommerce API creates an order automatically for a charge, so failed attempts were leaving bare/open Clover orders before the payment failed.

This build changes the card + Apple Pay flow to:

1. Create the complete Clover pickup order first.
2. Add the website line items, option notes, customer information, tax information when available, and pickup order type.
3. Send the Apple Pay/card single-use `clv_` token to Clover's documented `POST /v1/orders/{orderId}/pay` endpoint.
4. Request Clover's `delete_order_on_failure` behavior and also clean up a failed order if Clover leaves it behind.
5. Only mark the website order paid after Clover returns a successful paid response.
6. Print the same paid Clover order through Clover Print API after payment succeeds.
7. Never let printer/update failure turn a successful payment into a customer-facing payment failure.

Clover documents this order-first flow: create an order, then pay for it with the Ecommerce API. Clover also documents the `delete_order_on_failure` metadata behavior for failed payments.

## Apple Pay

The existing fresh Apple Pay session/listener logic remains in place. Each checkout creates a new wallet session for the current amount. The server now pays the pre-built Clover order instead of asking Clover to auto-create a blank order from the charge.

## Test

Use `?test=1` to show the Test category and the `Clover Print Test` item at $0.10. The test item has no sauce/drink/base customizations and has no tax.

Expected successful test in Clover:

- Order Type: Pickup / Take-Out (when the merchant's existing Clover order type is available)
- Customer information in order note
- `Clover Print Test` — $0.10
- Payment: PAID
- Station Duo print request

Do not repeat a real payment test if Clover shows a successful charge. First reconcile the Clover order/payment and the website order.

## Payment error behavior

The checkout now returns Clover's actual message/code when available instead of displaying only `402 Payment Required`.

## Logo

The payment screen uses the supplied FlameBachi logo at:

`online-menu/assets/flamebachi-payment-logo.png`
