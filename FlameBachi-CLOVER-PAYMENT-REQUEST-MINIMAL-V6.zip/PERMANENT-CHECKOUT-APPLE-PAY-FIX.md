# FlameBachi — checkout + Clover print test release

This release fixes the checkout cents/tax display and adds a controlled Clover $0.10 live-payment test mode.

## Checkout math
- Prices are calculated in integer cents.
- A single $1.00 item is $1.00 subtotal.
- Downtown LA tax is 10.250%.
- $1.00 item -> $0.10 tax -> $1.10 total.
- The checkout draft version is bumped to v4 and the previous v3 draft is cleared so an old duplicated test cart cannot be restored.

## Clover $0.10 test
Open the deployed site with `?test=1`.

The test section appears only in test mode and contains **Clover Print Test — $0.10**. It is a real $0.10 payment, not Clover testMode, so it exercises the production payment/order path. The test item is tax-exempt so the exact charge is $0.10.

Enter the customer's real test name and phone number before continuing to Clover. The customer name, phone, email (if entered), pickup location, website order number, and test marker are included in the Clover order note.

After the Clover charge succeeds:
1. Apple Pay/card receives the payment result without waiting for order printing.
2. The Clover order is synchronized.
3. The order is sent to Clover's default firing order printer with `print_event`.
4. The printer event and line-item sync are made retry-safe so a retry does not duplicate line items or print the same order again.

## Important
This is a real 10-cent production charge. Use it only for the controlled FlameBachi test. Do not run repeated charges unnecessarily.
