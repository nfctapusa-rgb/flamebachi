# FlameBachi Clover online-order fix

## What was wrong

The previous production flow could fail at Clover's payment step and then remove the temporary Clover order. That is why a failed Safari Apple Pay attempt could leave no order in Clover.

The pay-for-order request also did not send the explicit `amount` and `currency` fields documented by Clover for `POST /v1/orders/{orderId}/pay`.

## What this build changes

### Payment

- Creates one complete Clover order before payment.
- Pays that exact Clover order with the Apple Pay/card `clv_` token.
- Sends the explicit order amount in cents and `currency: usd`.
- Sends the customer email when available.
- Sends the website order number as Clover's external reference.
- Keeps the Clover order if Clover asks for 3-D Secure method/challenge verification.
- Finalizes 3-D Secure through `/v1/charges/finalize_payment` after the Clover 3DS SDK's `executePatch` event.
- Deletes the Clover order only for a definitive failed/declined payment, not for an intermediate 3DS flow.

### Customer information

Before creating the order, the backend looks for an existing Clover customer by phone/email. If none is found, it creates a Clover customer with the website customer's name, phone, and email.

That customer is attached to the Clover order. The order note also contains:

- Customer name
- Phone number
- Email when supplied
- Pickup location
- Website order number
- Payment method/status
- Tax
- Test-order marker when applicable

### Order contents

Every website cart item is sent as a Clover line item with:

- Item name
- Correct unit price
- Quantity
- Customization/options in the line-item note
- Clover tax rate when applicable
- Website discount as a Clover order-level discount when applicable

The Clover order total is the same server-authoritative total used by the website checkout.

### Printing

After successful payment, the same paid Clover order is sent to Clover's default order printer with `print_event`. The existing Station Duo/default order-printer routing is preserved.

Printing is treated as fulfillment work: a printer failure does not tell the customer that a successful payment failed.

## Important

Do not use the old package for another real Apple Pay test. Deploy this package first.

For the first production test, use the isolated `$0.10 Clover Print Test` item with `?test=1`. A successful result should show one real paid Clover order containing the test item, customer information, total, order type, and payment.
